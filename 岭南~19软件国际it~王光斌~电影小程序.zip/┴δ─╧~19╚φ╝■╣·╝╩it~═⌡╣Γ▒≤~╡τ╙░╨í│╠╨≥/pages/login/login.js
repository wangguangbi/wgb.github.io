Page({
  data:{},
  onLoad:function(options){
    //页面初始化，options为页面跳转所带来的参数
  },
  formSubmit:function(e){
    var user = e.detail.value;
    console.log(user);
    var name = user.name;
    var password = user.password;
    var users = wx.getStorageSync('users');
    for(var i = 0; i < users.length;i++){
      if(name == users[i].name && password == users[i].password){
        wx.setStorageSync('user',user);
        break;
      }
    }
    var u =wx.getStorageSync('user');
    if (u){
      wx.showToast({
        title:'登陆成功',
        icon:'success',
        duration:1000,
        success:function(){
          wx.navigateBack({
            delta: 1
          })
        }
      });
    }
  }
})