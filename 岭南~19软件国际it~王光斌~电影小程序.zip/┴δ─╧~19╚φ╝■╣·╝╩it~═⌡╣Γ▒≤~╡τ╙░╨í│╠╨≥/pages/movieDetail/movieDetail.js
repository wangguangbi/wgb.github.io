Page({
  data:{
    movie:{}
  },
  onLoad:function(e){
    this.loadMovieDetail(e);
  },
  loadMovieDetail:function(e){
      var page = this;
      wx.request({
        header:{
          "Content-Type":"json"
        },
        success:function (res){
          console.log(res);
          var subject = res.data;
          var movie = new Object();
            //电影名称
            movie.name = subjects.title;
            //电影海报图片
            movie.pic = subjects.images.medium;
            //导演
            var directors = subjects.directors;
            var dir ='';
            for(var j=0;j<directors.length;j++){
              dir +=directors[j].name+'';
            }
            movie.dir = dir;
            //主演
            var casts = subject.casts;
            var cast = '';
            for(var j=0;j<casts.length;j++){
              cast += casts[j].name+'';
            }
            movie.cast = cast;
            movie.id = subject.id;
            movie.year = subject.year;
            //影片类型
            var genres = subject.genres;
            var gen = '';
            for(var j=0;j<genres.length;j++){
              gen +=genres[j]+'';
            }
            movie.type = gen;
            movie.summary = subject.summary;
            movie.country = subject.countries[0];
          page.setData({movie:movie});
          wx.setNavigationBarTitle({
            title: movie.name
          })
        }
      });
    }
    })