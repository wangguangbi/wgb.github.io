Page({
  data: {
    currentTab: 0,
    indicatorDots: false,
    autoplay: true,
    interval: 5000,
    duration: 1000,
    imgUrls: [
      "/images/haibao/1.jpg",
      "/images/haibao/2.jpg",
      "/images/haibao/3.jpg",
      "/images/haibao/4.jpg"
    ],
    movies: [],
    flag: 0,
    comming: [{"id":428,"haspromotionTag":false,"img":"http://p0.meituan.net/w.h/moviemachine/b183a9143031dd4aab5ca95affe410f2579878.jpg","version":"v2d imax","nm":"指环王：王者无敌","preShow":false,"sc":9.5,"globalReleased":true,"wish":55667,"star":"伊莱贾·伍德,伊恩·麦克莱恩,西恩·奥斯汀","rt":"2021-05-14","showInfo":"今天10家影院放映13场","showst":3,"wishst":0,"comingTitle":"5月14日 周五"},{"id":1250700,"haspromotionTag":false,"img":"http://p0.meituan.net/w.h/moviemachine/735871b26fc55f7479087eae5e9f85722347572.jpg","version":"v2d imax","nm":"攀登者","preShow":false,"sc":9.4,"globalReleased":true,"wish":558579,"star":"吴京,章子怡,张译","rt":"2019-09-30","showInfo":"今天9家影院放映12场","showst":3,"wishst":0,"comingTitle":"2019年9月30日 周一"},{"id":1190390,"haspromotionTag":false,"img":"http://p0.meituan.net/w.h/movie/943dbccc5727cebddaabfd77117aa9052443827.jpg","version":"","nm":"迷妹罗曼史","preShow":false,"sc":0,"globalReleased":false,"wish":21239,"star":"闫妮,盛一伦,于小彤","rt":"2021-05-28","showInfo":"2021-05-28 本周五上映","showst":4,"wishst":0,"comingTitle":"5月28日 周五"},{"id":93,"haspromotionTag":false,"img":"http://p0.meituan.net/w.h/moviemachine/536d2921da64cbdb0b51f4b991e07ebb6142138.jpg","version":"","nm":"钱学森","preShow":false,"sc":0,"globalReleased":true,"wish":2164,"star":"陈坤,张雨绮,林永健","rt":"2021-05-01","showInfo":"今天6家影院放映6场","showst":3,"wishst":0,"comingTitle":"5月1日 周六"},{"id":1250964,"haspromotionTag":false,"img":"http://p1.meituan.net/w.h/movie/dc767baf42a73d7d769d27004a467a3a252607.jpg","version":"","nm":"无罪谋杀：科林尼案","preShow":false,"sc":0,"globalReleased":true,"wish":20264,"star":"埃利亚斯·穆巴里克,弗兰科·内罗,海纳·劳特尔巴赫","rt":"2021-05-14","showInfo":"今天3家影院放映6场","showst":3,"wishst":0,"comingTitle":"5月14日 周五"},{"id":1375624,"haspromotionTag":false,"img":"http://p1.meituan.net/w.h/movie/fe4306ca27c4ed1650dc39aa1a4df3a5650515.jpg","version":"v3d","nm":"潜艇总动员：地心游记","preShow":true,"sc":0,"globalReleased":false,"wish":16103,"star":"姚珊,筱柒,王琪","rt":"2021-06-12","showInfo":"2021-06-12上映","showst":4,"wishst":0,"comingTitle":"6月12日 周六"},{"id":1156913,"haspromotionTag":false,"img":"http://p1.meituan.net/w.h/movie/b285d40c64ac90a74f8c541f3890b9191285394.jpg","version":"","nm":"匹诺曹","preShow":false,"sc":0,"globalReleased":false,"wish":36984,"star":"托尼·塞尔维洛,费德里科·伊帕迪,罗伯托·贝尼尼","rt":"2021-06-01","showInfo":"2021-06-01 下周二上映","showst":4,"wishst":0,"comingTitle":"6月1日 周二"},{"id":1251152,"haspromotionTag":false,"img":"http://p0.meituan.net/w.h/movie/fd99a088f950493a4db907f378c28f7a3430514.png","version":"","nm":"柳青","preShow":false,"sc":0,"globalReleased":true,"wish":1022,"star":"成泰燊,丹琳,师清峰","rt":"2021-05-21","showInfo":"今天2家影院放映4场","showst":3,"wishst":0,"comingTitle":"5月21日 周五"},{"id":1425171,"haspromotionTag":false,"img":"http://p0.meituan.net/w.h/moviemachine/712be8078f1c2aeb94f0462855dc8a12692845.jpg","version":"","nm":"九零后","preShow":false,"sc":0,"globalReleased":false,"wish":13294,"star":"杨振宁,许渊冲","rt":"2021-05-29","showInfo":"2021-05-29 本周六上映","showst":4,"wishst":0,"comingTitle":"5月29日 周六"},{"id":1355429,"haspromotionTag":false,"img":"http://p1.meituan.net/w.h/movie/23e815cc365c9960d5123315ed223c332130336.jpg","version":"v3d","nm":"疯狂丑小鸭2靠谱英雄","preShow":true,"sc":0,"globalReleased":false,"wish":11677,"star":"苏旖旎,王雪沁,许子尧","rt":"2021-06-12","showInfo":"2021-06-12上映","showst":4,"wishst":0,"comingTitle":"6月12日 周六"}]
  },
  onLoad: function (options) {
    // this.loadMovies();
  },
  switchNav: function (e) {
    var page = this;
    if (this.data.currentTab == e.target.dataset.current) {
      return false;
    } else {
      page.setData({
        currentTab: e.target.dataset.current
      });
    }
  },
  loadMovies: function () {
    var page = this;
    wx.request({
      url: 'https://m.maoyan.com/ajax/moreComingList?token=&movieIds=428%2C1250700%2C1190390%2C93%2C1250964%2C1375624%2C1156913%2C1251152%2C1425171%2C1355429&optimus_uuid=29217460BD4A11EBA17B87259397096DDAFCA16ADCB44F779320631B03856600&optimus_risk_level=71&optimus_code=10',
      method: "GET",
      header: {
        "Content-Type": "json"
      },
      success: (res) => {

        this.setData({
          comming: res.comming
        })
      }
    })
  },
  switchMonth: function (e) {
    console.log(e);
    var page = this;
    if (this.data.flag == e.target.id) {
      return false;
    } else {
      page.setData({
        flag: e.target.id
      });
    }
  },
  loadMoviesDetail: function (e) {
    console.log(e);
    var id = e.currentTarget.id;
    console.log(id);
    wx.navigateTo({
      url: '../movieDetail/movieDetail?id=' + id
    })
  },
  onShareAppMessage: function () {
    return {
      title: '电影列表',
      path: '../movie/movie'
    }
  }
})