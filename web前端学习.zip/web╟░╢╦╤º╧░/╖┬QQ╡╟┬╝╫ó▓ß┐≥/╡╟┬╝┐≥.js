// JavaScript Document
window.onload = function(){
	var head_divs = document.getElementById("t-head").getElementsByTagName("div");
	var current_index=0;
	for(var i=0;i<head_divs.length;i++){
		head_divs[i].onclick = function(){
			if(i != current_index){
				head_divs[current_index].style.backgroundColor = '';
				head_divs[current_index].style.borderBottom = '';
			}
			var body_uls = document.getElementById("t-body").getElementsByTagName("ul");
			for(var i=0;i<body_uls.length;i++){
				body_uls[i].className = body_uls[i].className.replace(" current","");
				head_divs[i].className = head_divs[i].className.replace(" current","");
				if(head_divs[i] == this){
					this.className += " current";
					body_uls[i].className += " current";
				}
			}
		}
	}
}