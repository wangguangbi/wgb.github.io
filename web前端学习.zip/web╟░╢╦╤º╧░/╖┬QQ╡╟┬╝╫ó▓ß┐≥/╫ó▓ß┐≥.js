// JavaScript Document
function checkEmpty(this){
	if(!obj.value){
		obj.nextSibling.style.display = 'block';
	}else{
		obj.nextSibling.style.display = 'none';
	}
}
function checkPwd(obj){
	var pwd = document.getElementById('pwd').value;
	var pwdAgain = obj.value;

	if(pwd != pwdAgain){
		obj.nextSibling.style.display = 'block';
	}
	else{
		obj.nextSibling.style.display = 'none';
	}
}