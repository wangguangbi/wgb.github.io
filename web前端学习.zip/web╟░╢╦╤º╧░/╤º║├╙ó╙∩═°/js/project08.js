// JavaScript Document
//设置页面载入的事件
window.onload=function()
{
	//轮播图
	function hotChange()
	{
		var current_index=0;//元素的初始下标
		var timer=window.setInterval(autoChange,1000);//定义计时器
		var pic_li=document.getElementById("banner_pic").getElementsByTagName("li");//获取图片li数组
		var button_li=document.getElementById("button").getElementsByTagName("li");//按钮的li数组
		
		//鼠标事件
		for(var i=0;i<button_li.length;i++)
		{
			button_li[i].onmouseover=function()//鼠标放上按钮
			{
				if(timer)//计时器正在运行
				{
					clearInterval(timer);//停止计时器
				}
				for(var j=0;j<button_li.length;j++)
				{
					if(button_li[j]==this)//如果选中某个按钮
					{
						current_index=j;//将当前选中的元素下标赋给变量
						button_li[j].className="current";
					    pic_li[j].className="current";
					}
					else
					{
						button_li[j].className="but";
					    pic_li[j].className="pic";
					}
				}
			}
			button_li[i].onmouseout=function()//鼠标离开
			{
				timer=window.setInterval(autoChange,1000);//重启计时器
			}
		}
		
		
		
		//自动轮播
		function autoChange()
		{
			++current_index;//自动递增
			if(current_index==button_li.length)
			{
				current_index=0;
			}
			for(var i=0;i<button_li.length;i++)
			{
				if(i==current_index)
				{
					button_li[i].className="current";
					pic_li[i].className="current";
				}
				else
				{
					button_li[i].className="but";
					pic_li[i].className="pic";
				}
			}
			
		}
		
	}
	hotChange();//调用函数
	
	//跑马灯
	function school()
	{
		//跑马灯的速度
		var speed=10;
		//获取div对象
		var imgbox=document.getElementById("imgbox");
		//复制一个span标签，用于无缝滚动
		imgbox.innerHTML += imgbox.innerHTML;
		//获取两个span元素
		var spans=imgbox.getElementsByTagName("span");
		//定义计时器
		var timer1=window.setInterval(marquee,speed);
		//鼠标事件
		imgbox.onmouseover=function()
		{
			clearInterval(timer1);
		}
		imgbox.onmouseout=function()
		{
			timer1=window.setInterval(marquee,speed);
		}
		
		function marquee()
		{
			//当第一个span被完全卷出的时候
			if(imgbox.scrollLeft>spans[0].offsetWidth)
			{
				imgbox.scrollLeft=0;
			}
			else
			{
				++imgbox.scrollLeft;
			}
		}
	}
	school();//调用函数
	
	//tab切换
	function tableChange()
	{
		var current_index=0;//元素的初始下标
		var timer=window.setInterval(autoChange,3000);//定义计时器
		//获取SwitchBigPic里的span标签数组
		var spans=document.getElementById("SwitchBigPic").getElementsByTagName("span");
		//SwitchNav里面的li元素
		var lis=document.getElementById("SwitchNav").getElementsByTagName("li");
		//鼠标事件
		for(var i=0;i<lis.length;i++)
		{
			lis[i].onmouseover=function()//鼠标放上按钮
			{
				if(timer)//计时器正在运行
				{
					clearInterval(timer);//停止计时器
				}
				for(var j=0;j<lis.length;j++)
				{
					if(lis[j]==this)//如果选中某个按钮
					{
						current_index=j;//将当前选中的元素下标赋给变量
						spans[j].className="sp";
					}
					else
					{
						spans[j].className="";
					}
				}
			}
			lis[i].onmouseout=function()//鼠标离开
			{
				timer=window.setInterval(autoChange,1000);//重启计时器
			}
		}
		
		
		
		//自动轮播
		function autoChange()
		{
			++current_index;//自动递增
			if(current_index==lis.length)
			{
				current_index=0;
			}
			for(var i=0;i<lis.length;i++)
			{
				if(i==current_index)
				{
					spans[i].className="sp";
				}
				else
				{
					spans[i].className="";
				}
			}
			
		}
	}
	tableChange();//调用函数
}