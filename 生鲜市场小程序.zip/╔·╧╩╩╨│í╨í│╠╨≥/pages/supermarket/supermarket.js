Page({
  data:{
    //菜单导航
    currentTab:0,//导航菜单对应内容面板序号值
    flag:0,//菜单是否被选中序号值
    goods:[]
  },
  onLoad:function(options){
    this.loadGoods;
  },
  switchNav:function(e){
    console.log(e);
    var page = this;
    var id = e.target.id;
    if(this.data.currentTab == id){
      return false;
    }else{
      page.setData({currentTab:id});
    }
    page.setData({flag:id});
  },
  loadGoods:function(){
    var goods = wx.getStorageSync('goods');
    var result = [];
    for(var i = 0; i<goods.length;i++){
      var good = goods[i];
      console.log(good);
      var type = good.type;
      if(type.indexOf('supermarket') > -1){
        result.push(good);
      }
    }
    console.log(result);
    this.setData({ goods:result });
  },
  addGoods:function(e){
    var goods = wx.getStorageSync('goods');
    var id = e.currentTarget.id;
    var good = {};
    for(var i=0;i<goods.length;i++){
      var oldGood = goods[i];
      if(oldGood.id==id){
        good = oldGood;
        break;
      }
    }
    var orders = wx.getStorageSync('orders');
    var addOrders = new Array();
    var add = true;
    for(var i=0;i<orders.length;i++){
      var order = orders[i];
      if(order.id == good.id){
        var count = order.count;
        order.count = count + 1;
        add = false;
      }
      addOrders[i] = order;
    }
    var len = orders.length;
    if(add){
      good.cout = 1;
      addOrders[len] = good;
    }
    wx.setStorageSync('orders', addOrders);
    wx.showToast({
      title: '添加成功',
      icon:'success',
      duration:1000
    });
  }
})