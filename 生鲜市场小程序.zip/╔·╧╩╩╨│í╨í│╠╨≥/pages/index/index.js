//swiper滑块视图容器
Page({
  data:{
    indicatorDots:false,/*不显示面板指示点*/
    autoplay:true,/*自动切换*/
    interval:2000,/*自动切换时间间隔2秒*/
    duration:1000,/*滑动动画时长1秒*/
    imgUrls:[
      "/images/haibao1.jpg",
      "/images/haibao2.jpg",
      "/images/haibao3.jpg",
      "/images/haibao4.jpg"
    ], 
  //swiper滑块视图容器
    goods:[]
  },
//将本地数据为fruits类别的商品信息保存
  onLoad:function(){
    this.loadGoods();
  },
  loadGoods:function(){
    var goods = wx.getStorageSync('goods');
    var result = [];
    for(var i = 0; i<goods.length;i++){
      var good = goods[i];
      console.log(good);
      var type = good.type;
      if(type.indexOf('fruits') > -1){
        result.push(good);
      }
    }
    console.log(result);
    this.setData({goods:result});
  },
  //将本地数据为fruits类别的商品信息保存
  //添加addGoods函数，单击可添加到购物车，并提示成功
  addGoods:function(e){
    var goods = wx.getStorageSync('goods');
    var id = e.currentTarget.id;
    var good = {};
    for(var i=0;i<goods.length;i++){
      var oldGood = goods[i];
      if(oldGood.id==id){
        good = oldGood;
        break;
      }
    }
    var orders = wx.getStorageSync('orders');
    var addOrders = new Array();
    var add = true;
    for(var i=0;i<orders.length;i++){
      var order = orders[i];
      if(order.id == good.id){
        var count = order.count;
        order.count = count + 1;
        add = false;
      }
      addOrders[i] = order;
    }
    var len = orders.length;
    if(add){
      good.cout = 1;
      addOrders[len] = good;
    }
    wx.setStorageSync('orders', addOrders);
    wx.showToast({
      title: '添加成功',
      icon:'success',
      duration:1000
    });
  }
})
//添加addGoods函数，单击可添加到购物车，并提示成功