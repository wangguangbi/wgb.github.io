// app.js
App({
  onLaunch:function(){
    //调用API从本地缓存中获取数据
    var users = wx.getStorageSync('users');
    if(!users){
      users = this.loadUsers();
      wx.setStorageSync('users', users);
      var goods = wx.getStorageSync('goods');
      if(!goods){
        goods = this.loadGoods();
        wx.setStorageSync('goods', goods);
      }
    }
  },
  getUserInfo:function(cb){
    var that = this
    if(this.globalData.userInfo){
      typeof cb == "function" && cb(this.globalData.userInfo)
    }else{
      //调用登录接口
      wx.login({
        success:function(){
          wx.getUserInfo({
            success:function(res){
              that.globalData.userInfo = res.userInfo
              typeof cb == "function" && cb(that.globalData.userInfo)
            }
          })
        }
      })
    }
  },
//初始化商品信息
  loadGoods:function(){
    var goods = new Array();

    var good = new Object();
    good.id="0";
    good.pic = '/images/index/17.jpg';
    good.pic='海南香蕉500g';
    good.price='4';
    good.type='fruits.supermarket'
    goods[0] = good;

    var good1 = new Object();
    good1.id="1";
    good1.pic = '/images/index/18.jpg';
    good1.pic='新疆哈密瓜500g';
    good1.price='3.5';
    good1.type='fruits.supermarket'
    goods[1] = good1;

    var good2 = new Object();
    good2.id="2";
    good2.pic = '/images/index/19.jpg';
    good2.pic='山东红富士500g';
    good2.price='7.5';
    good2.type='fruits.supermarket'
    goods[2] = good2;

    var good3 = new Object();
    good3.id="3";
    good3.pic = '/images/index/20.jpg';
    good3.pic='广西桂七芒500g';
    good3.price='4';
    good3.type='fruits.supermarket'
    goods[3] = good3;

    var good4 = new Object();
    good4.id="4";
    good4.pic = '/images/chaoshi/01.jpg';
    good4.pic='台湾红心火龙果';
    good4.price='4';
    good4.type='supermarket'
    goods[4] = good4;

    var good5 = new Object();
    good5.id="5";
    good5.pic = '/images/chaoshi/02.jpg';
    good5.pic='喜子郎果冻';
    good5.price='15';
    good5.type='supermarket'
    goods[5] = good5;

    var good6 = new Object();
    good6.id="6";
    good6.pic = '/images/chaoshi/03.jpg';
    good6.pic='红牛维生素功能饮料';
    good6.price='5';
    good6.type='supermarket'
    goods[6] = good6;

    var good7 = new Object();
    good7.id="7";
    good7.pic = '/images/chaoshi/04.jpg';
    good7.pic='德芙巧克力';
    good7.price='18';
    good7.type='supermarket'
    goods[7] = good7;
  },
  globalData:{
    userInfo:null
  }
})
